<h2><?php esc_attr_e( 'Alternative Colours', 'wp_admin_style' ); ?></h2>

<div style="width:99%; padding: 5px;"><?php esc_attr_e( 'without class', 'wp_admin_style' ); ?></div>
<div style="width:99%; padding: 5px;" class="updated">class .updated</div>
<div style="width:99%; padding: 5px;" class="alternate">class .alternate</div>
<div style="width:99%; padding: 5px;" class="alte">class .alt</div>
<div style="width:99%; padding: 5px;" class="form-invalid">class .form-invalid</div>
