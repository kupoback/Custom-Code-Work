<h2><?php esc_attr_e( 'Tabs', 'wp_admin_style' ); ?></h2>
<h2 class="nav-tab-wrapper">
	<a href="#" class="nav-tab">Tab #1</a>
	<a href="#" class="nav-tab nav-tab-active">Tab #2</a>
	<a href="#" class="nav-tab">Tab #3</a>
</h2>
