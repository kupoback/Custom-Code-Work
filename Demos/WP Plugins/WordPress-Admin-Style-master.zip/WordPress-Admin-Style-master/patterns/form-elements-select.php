<h2><?php esc_attr_e( 'Form Elements Select', 'wp_admin_style' ); ?></h2>

<select name="" id="">
	<option selected="selected" value="">Example option</option>
	<option value="">foo</option>
</select>
